
### Loading Data


```python
import pandas as pd 
import numpy as np
data = pd.read_csv("/Users/bhavya.bhambri/Desktop/MEXProjects/MEXLifecycle/mex_lifecycle_v2.csv")
```

    /Users/bhavya.bhambri/anaconda3/lib/python3.7/site-packages/IPython/core/interactiveshell.py:3049: DtypeWarning: Columns (5) have mixed types. Specify dtype option on import or set low_memory=False.
      interactivity=interactivity, compiler=compiler, result=result)



```python
city_mapping = pd.read_csv("/Users/bhavya.bhambri/Desktop/MEXProjects/MEXLifecycle/country_mapping.csv")
```


```python
data_merged = data.merge(city_mapping, how='inner', left_index=True,on='city_id')
```


```python
data_merged.columns
```




    Index(['merchant_id', 'zeus_created_at', 'country_id_x', 'city_id',
           'business_name', 'is_partner', 'is_active', 'business_model',
           'latest_commission_rate', 'is_bd_account', 'is_bd_partner',
           'first_completed_order_date', 'last_completed_order_date',
           'zeus_days_to_first_order', 'zeus_menu_creation_date',
           'days_to_first_order', 'days_to_activation', 'life_time_trips',
           'life_time_gmv_earned_usd', 'life_time_gmv_earned_local',
           'life_time_uniq_pax', 'food_trips_first_week', 'food_trips_second_week',
           'food_trips_third_week', 'food_trips_fourth_week',
           'food_trips_fifth_week', 'food_trips_sixth_week',
           'food_trips_seventh_week', 'food_trips_eighth_week',
           'food_trips_ninth_week', 'food_trips_tenth_week', 'city_name',
           'country_id_y', 'country_name'],
          dtype='object')




```python

```


```python
data_merged
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>merchant_id</th>
      <th>zeus_created_at</th>
      <th>country_id_x</th>
      <th>city_id</th>
      <th>business_name</th>
      <th>is_partner</th>
      <th>is_active</th>
      <th>business_model</th>
      <th>latest_commission_rate</th>
      <th>is_bd_account</th>
      <th>...</th>
      <th>food_trips_fifth_week</th>
      <th>food_trips_sixth_week</th>
      <th>food_trips_seventh_week</th>
      <th>food_trips_eighth_week</th>
      <th>food_trips_ninth_week</th>
      <th>food_trips_tenth_week</th>
      <th>city_name</th>
      <th>country_id_y</th>
      <th>country_name</th>
      <th>dormant</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>18</th>
      <td>2-CYTKGX2AUF5UV6</td>
      <td>2019-06-19 09:08:20</td>
      <td>2</td>
      <td>4</td>
      <td>Kowloon House</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>268</td>
      <td>258</td>
      <td>228</td>
      <td>220</td>
      <td>230</td>
      <td>225</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CY2HN34JJN6DVJ</td>
      <td>2019-10-11 04:05:48</td>
      <td>2</td>
      <td>4</td>
      <td>Chicken Pile</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>9</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYMVWGDWCFEJHE</td>
      <td>2019-05-08 07:17:53</td>
      <td>2</td>
      <td>4</td>
      <td>Jollibee</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>277</td>
      <td>299</td>
      <td>301</td>
      <td>348</td>
      <td>327</td>
      <td>409</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYVULNXXCTCXJT</td>
      <td>2019-08-07 04:48:14</td>
      <td>2</td>
      <td>4</td>
      <td>Ate Rica's Bacsilog</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>38</td>
      <td>21</td>
      <td>37</td>
      <td>36</td>
      <td>33</td>
      <td>24</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYNUCLK2NYKABA</td>
      <td>2019-05-29 06:55:38</td>
      <td>2</td>
      <td>4</td>
      <td>Papa John's Pizza</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>10</td>
      <td>11</td>
      <td>25</td>
      <td>14</td>
      <td>28</td>
      <td>12</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CY3VVKXGBFMEVN</td>
      <td>2019-11-09 09:44:46</td>
      <td>2</td>
      <td>4</td>
      <td>Something Healthy</td>
      <td>True</td>
      <td>True</td>
      <td>Integrated</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>AWjFi1mOkk5cOZVWvPU8</td>
      <td>2019-02-07 01:21:10</td>
      <td>2</td>
      <td>4</td>
      <td>Krispy Kreme</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>11</td>
      <td>20</td>
      <td>10</td>
      <td>7</td>
      <td>14</td>
      <td>27</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYWTREE2TBNJVA</td>
      <td>2019-08-29 09:31:38</td>
      <td>2</td>
      <td>4</td>
      <td>Booba Milk Tea Shop</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>8</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYUCE3DELKE3AN</td>
      <td>2019-07-04 07:47:44</td>
      <td>2</td>
      <td>4</td>
      <td>Hukad</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>5</td>
      <td>8</td>
      <td>7</td>
      <td>4</td>
      <td>14</td>
      <td>8</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CY2CR65KEX4XGN</td>
      <td>2019-10-05 12:09:29</td>
      <td>2</td>
      <td>4</td>
      <td>Jollibee</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>AWgnUZqi5b9pQDOtww7I</td>
      <td>2019-01-07 07:58:05</td>
      <td>2</td>
      <td>4</td>
      <td>Papas</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYUZVKXCRFKFRA</td>
      <td>2019-07-21 07:04:42</td>
      <td>2</td>
      <td>4</td>
      <td>KFC</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>93</td>
      <td>108</td>
      <td>125</td>
      <td>151</td>
      <td>170</td>
      <td>160</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYV2G25KN6TWVT</td>
      <td>2019-08-15 02:32:49</td>
      <td>2</td>
      <td>4</td>
      <td>Tapa King</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>127</td>
      <td>166</td>
      <td>139</td>
      <td>89</td>
      <td>65</td>
      <td>73</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYXGAAEKJ75GLT</td>
      <td>2019-09-16 02:14:49</td>
      <td>2</td>
      <td>4</td>
      <td>Shawarma Shack</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CY3KEXATTT6JGN</td>
      <td>2019-11-05 03:36:50</td>
      <td>2</td>
      <td>4</td>
      <td>Tita's Turon</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYTCKGNVAE5VNX</td>
      <td>2019-06-11 10:46:32</td>
      <td>2</td>
      <td>4</td>
      <td>Andok's</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>8</td>
      <td>6</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYMHN7AWNF5ZTE</td>
      <td>2019-05-02 03:23:33</td>
      <td>2</td>
      <td>4</td>
      <td>Chowking</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>305</td>
      <td>254</td>
      <td>270</td>
      <td>242</td>
      <td>253</td>
      <td>300</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYWKTUCFJFC1JN</td>
      <td>2019-08-28 09:27:25</td>
      <td>2</td>
      <td>4</td>
      <td>Sisig Hooray</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>5</td>
      <td>5</td>
      <td>6</td>
      <td>2</td>
      <td>9</td>
      <td>7</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYNFWCLJVNJULX</td>
      <td>2019-05-23 08:09:08</td>
      <td>2</td>
      <td>4</td>
      <td>Juice Avenue</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYMWAGCAHBX2GT</td>
      <td>2019-05-08 07:50:40</td>
      <td>2</td>
      <td>4</td>
      <td>Chowking</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>181</td>
      <td>223</td>
      <td>212</td>
      <td>212</td>
      <td>156</td>
      <td>166</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYWJRT2TJEJ2ET</td>
      <td>2019-08-27 02:51:50</td>
      <td>2</td>
      <td>4</td>
      <td>Uncle John's Chicken by Mini Stop</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>20</td>
      <td>13</td>
      <td>22</td>
      <td>12</td>
      <td>12</td>
      <td>17</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CY3UUBUDEJDTBA</td>
      <td>2019-11-08 04:50:23</td>
      <td>2</td>
      <td>4</td>
      <td>1166 Bistro and Bar</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYMXTRKWWFDHPE</td>
      <td>2019-05-10 10:25:33</td>
      <td>2</td>
      <td>4</td>
      <td>Reyes Barbecue</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>7</td>
      <td>4</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>AWhenYdHcEjWIUmPsNGq</td>
      <td>2019-01-18 01:40:08</td>
      <td>2</td>
      <td>4</td>
      <td>Chooks To Go</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>32</td>
      <td>34</td>
      <td>20</td>
      <td>27</td>
      <td>38</td>
      <td>41</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CY31VBN1JJEBG2</td>
      <td>2019-11-15 04:03:17</td>
      <td>2</td>
      <td>4</td>
      <td>Ababu Persian Kitchen</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYNDEYMYSBMAEN</td>
      <td>2019-05-20 04:12:55</td>
      <td>2</td>
      <td>4</td>
      <td>Uncle John's Chicken by Mini Stop</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>51</td>
      <td>56</td>
      <td>32</td>
      <td>25</td>
      <td>30</td>
      <td>35</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYVZT22EETWALE</td>
      <td>2019-08-13 08:51:44</td>
      <td>2</td>
      <td>4</td>
      <td>Robinsons Food To Go</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYNFVPB1CAT1GN</td>
      <td>2019-05-23 06:37:17</td>
      <td>2</td>
      <td>4</td>
      <td>Book &amp; Borders Cafe</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>6</td>
      <td>5</td>
      <td>7</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CY2CR65KGE4JEX</td>
      <td>2019-10-05 12:09:29</td>
      <td>2</td>
      <td>4</td>
      <td>Jollibee</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2-CYUJJX51LKWCN2</td>
      <td>2019-07-11 11:42:57</td>
      <td>2</td>
      <td>4</td>
      <td>Turks</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>12</td>
      <td>8</td>
      <td>13</td>
      <td>15</td>
      <td>9</td>
      <td>9</td>
      <td>Metro Manila</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY2BRAJVWA3UEJ</td>
      <td>2019-10-04 06:21:52</td>
      <td>2</td>
      <td>23</td>
      <td>Quan</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY3ZCYUHCPD1AT</td>
      <td>2019-11-13 03:27:07</td>
      <td>2</td>
      <td>23</td>
      <td>Bascon's Cafe</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY2BRFW2EJNWDA</td>
      <td>2019-10-04 06:47:58</td>
      <td>2</td>
      <td>23</td>
      <td>Fudmaster</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CYXGDB5BAXDBAJ</td>
      <td>2019-09-16 07:26:01</td>
      <td>2</td>
      <td>23</td>
      <td>BongBong's</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CYXUKE3GRNKGGA</td>
      <td>2019-09-22 10:48:46</td>
      <td>2</td>
      <td>23</td>
      <td>Zark's Burgers</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY2TEK5GLFAUC2</td>
      <td>2019-10-14 03:12:46</td>
      <td>2</td>
      <td>23</td>
      <td>Jollibee</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY2BRU3KA7XDPE</td>
      <td>2019-10-04 07:38:49</td>
      <td>2</td>
      <td>23</td>
      <td>2 Story Kitchen</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>24</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY2BNVJFKAVUC2</td>
      <td>2019-10-04 04:55:05</td>
      <td>2</td>
      <td>23</td>
      <td>Kopisina</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY3KFFXXAPUWGX</td>
      <td>2019-11-05 04:54:54</td>
      <td>2</td>
      <td>23</td>
      <td>Tokyo Tokyo</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY2TEK5GLU23JX</td>
      <td>2019-10-14 03:12:46</td>
      <td>2</td>
      <td>23</td>
      <td>Jollibee</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>True</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CYXVAVMVLNU2LN</td>
      <td>2019-09-23 02:16:12</td>
      <td>2</td>
      <td>23</td>
      <td>Fat Choi Chinese Kitchen</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>36</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CYXGDB5BANUHLT</td>
      <td>2019-09-16 07:26:01</td>
      <td>2</td>
      <td>23</td>
      <td>BongBong's</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>True</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CYXHVBCXCA6HV6</td>
      <td>2019-09-18 07:07:34</td>
      <td>2</td>
      <td>23</td>
      <td>Merzci</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY2EJNAULFE2UA</td>
      <td>2019-10-07 10:10:11</td>
      <td>2</td>
      <td>23</td>
      <td>Mr. Freeze 100% Purified Tube Ice</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY3ZCZLJSE3HGT</td>
      <td>2019-11-13 03:32:28</td>
      <td>2</td>
      <td>23</td>
      <td>La Primavera Fruits and Vegetables</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>True</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CYXGDB5BAGAJRT</td>
      <td>2019-09-16 07:26:01</td>
      <td>2</td>
      <td>23</td>
      <td>BongBong's</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>True</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY3ZCN3BVN2AAJ</td>
      <td>2019-11-13 02:48:41</td>
      <td>2</td>
      <td>23</td>
      <td>Maria Kucina Familia</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY2UVTT3BCMBNE</td>
      <td>2019-10-16 02:50:19</td>
      <td>2</td>
      <td>23</td>
      <td>L'Kaisei Food Corporation</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY2FUAW2L6L1HE</td>
      <td>2019-10-09 02:31:18</td>
      <td>2</td>
      <td>23</td>
      <td>Aida's</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY2EHBWYTXTGJT</td>
      <td>2019-10-07 08:57:55</td>
      <td>2</td>
      <td>23</td>
      <td>Felicia's</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY2BPFXDRRK3GE</td>
      <td>2019-10-04 06:14:43</td>
      <td>2</td>
      <td>23</td>
      <td>Quan</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CYXVAVMVMEAWJX</td>
      <td>2019-09-23 02:16:12</td>
      <td>2</td>
      <td>23</td>
      <td>Fat Choi Chinese Kitchen</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>18</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CYXGDB5BAXVJBE</td>
      <td>2019-09-16 07:26:01</td>
      <td>2</td>
      <td>23</td>
      <td>BongBong's</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CY2FUAW2LEKVA6</td>
      <td>2019-10-09 02:31:18</td>
      <td>2</td>
      <td>23</td>
      <td>Byron's Backribs Grille</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CYXTJ733N2BUGN</td>
      <td>2019-09-21 06:35:39</td>
      <td>2</td>
      <td>23</td>
      <td>Jaimies Cafe</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>23</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2-CYXHVBCXCYJHGA</td>
      <td>2019-09-18 07:07:34</td>
      <td>2</td>
      <td>23</td>
      <td>Merzci</td>
      <td>True</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Bacolod</td>
      <td>2</td>
      <td>Philippines</td>
      <td>False</td>
    </tr>
    <tr>
      <th>143</th>
      <td>6-CYWYR8DUDAN3NA</td>
      <td>2019-09-04 06:17:51</td>
      <td>6</td>
      <td>225</td>
      <td>Ayam Jerit</td>
      <td>False</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>23</td>
      <td>22</td>
      <td>12</td>
      <td>16</td>
      <td>14</td>
      <td>3</td>
      <td>Curup</td>
      <td>6</td>
      <td>Indonesia</td>
      <td>False</td>
    </tr>
    <tr>
      <th>143</th>
      <td>6-CYXJTJE1KFNVGE</td>
      <td>2019-09-19 08:34:57</td>
      <td>6</td>
      <td>225</td>
      <td>Miso Ayam Cak Ji'in</td>
      <td>False</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Curup</td>
      <td>6</td>
      <td>Indonesia</td>
      <td>False</td>
    </tr>
    <tr>
      <th>143</th>
      <td>6-CYX1NUU3NUADDE</td>
      <td>2019-09-29 13:43:59</td>
      <td>6</td>
      <td>225</td>
      <td>Mie Ayam Habil</td>
      <td>False</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>11</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Curup</td>
      <td>6</td>
      <td>Indonesia</td>
      <td>False</td>
    </tr>
    <tr>
      <th>143</th>
      <td>6-CYX1NUU3NYLWGJ</td>
      <td>2019-09-29 13:43:59</td>
      <td>6</td>
      <td>225</td>
      <td>Pecel Lele Etek</td>
      <td>False</td>
      <td>True</td>
      <td>Concierge</td>
      <td>0</td>
      <td>False</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Curup</td>
      <td>6</td>
      <td>Indonesia</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>199308 rows × 35 columns</p>
</div>




```python
data_merged.isnull().values.any()
```




    True




```python
data_merged.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country_id_x</th>
      <th>city_id</th>
      <th>latest_commission_rate</th>
      <th>zeus_days_to_first_order</th>
      <th>days_to_first_order</th>
      <th>days_to_activation</th>
      <th>life_time_trips</th>
      <th>life_time_gmv_earned_usd</th>
      <th>life_time_gmv_earned_local</th>
      <th>life_time_uniq_pax</th>
      <th>...</th>
      <th>food_trips_second_week</th>
      <th>food_trips_third_week</th>
      <th>food_trips_fourth_week</th>
      <th>food_trips_fifth_week</th>
      <th>food_trips_sixth_week</th>
      <th>food_trips_seventh_week</th>
      <th>food_trips_eighth_week</th>
      <th>food_trips_ninth_week</th>
      <th>food_trips_tenth_week</th>
      <th>country_id_y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>199349.000000</td>
      <td>199349.000000</td>
      <td>199349.000000</td>
      <td>175921.000000</td>
      <td>175916.000000</td>
      <td>199250.000000</td>
      <td>199349.000000</td>
      <td>176015.000000</td>
      <td>1.760150e+05</td>
      <td>199349.000000</td>
      <td>...</td>
      <td>199349.000000</td>
      <td>199349.000000</td>
      <td>199349.000000</td>
      <td>199349.000000</td>
      <td>199349.000000</td>
      <td>199349.000000</td>
      <td>199349.000000</td>
      <td>199349.000000</td>
      <td>199349.000000</td>
      <td>199349.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5.512814</td>
      <td>24.542586</td>
      <td>0.101522</td>
      <td>13.000477</td>
      <td>13.672241</td>
      <td>0.146103</td>
      <td>479.117568</td>
      <td>2882.648617</td>
      <td>2.726510e+07</td>
      <td>304.676843</td>
      <td>...</td>
      <td>17.727037</td>
      <td>39.314117</td>
      <td>20.079408</td>
      <td>19.883732</td>
      <td>19.167239</td>
      <td>18.838850</td>
      <td>18.335387</td>
      <td>18.015194</td>
      <td>17.677861</td>
      <td>5.512814</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.199259</td>
      <td>19.818266</td>
      <td>0.102112</td>
      <td>25.144848</td>
      <td>25.301464</td>
      <td>4.857025</td>
      <td>2027.537343</td>
      <td>11923.055387</td>
      <td>1.463835e+08</td>
      <td>1092.482156</td>
      <td>...</td>
      <td>69.967492</td>
      <td>143.931430</td>
      <td>75.277325</td>
      <td>75.863644</td>
      <td>74.254625</td>
      <td>75.537262</td>
      <td>74.202713</td>
      <td>76.690602</td>
      <td>76.167959</td>
      <td>1.199259</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-283.000000</td>
      <td>1.000000</td>
      <td>0.280743</td>
      <td>6.200000e+00</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>6.000000</td>
      <td>10.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>5.000000</td>
      <td>36.773871</td>
      <td>2.020000e+05</td>
      <td>4.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>6.000000</td>
      <td>18.000000</td>
      <td>0.120000</td>
      <td>4.000000</td>
      <td>5.000000</td>
      <td>0.000000</td>
      <td>40.000000</td>
      <td>230.701539</td>
      <td>1.481750e+06</td>
      <td>32.000000</td>
      <td>...</td>
      <td>2.000000</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>6.000000</td>
      <td>34.000000</td>
      <td>0.181800</td>
      <td>14.000000</td>
      <td>14.000000</td>
      <td>0.000000</td>
      <td>253.000000</td>
      <td>1373.096213</td>
      <td>9.991000e+06</td>
      <td>187.000000</td>
      <td>...</td>
      <td>12.000000</td>
      <td>25.000000</td>
      <td>12.000000</td>
      <td>11.000000</td>
      <td>10.000000</td>
      <td>9.000000</td>
      <td>8.000000</td>
      <td>7.000000</td>
      <td>7.000000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>9.000000</td>
      <td>228.000000</td>
      <td>1.000000</td>
      <td>310.000000</td>
      <td>311.000000</td>
      <td>192.000000</td>
      <td>136393.000000</td>
      <td>782619.306603</td>
      <td>1.344559e+10</td>
      <td>62541.000000</td>
      <td>...</td>
      <td>5050.000000</td>
      <td>8385.000000</td>
      <td>4021.000000</td>
      <td>4059.000000</td>
      <td>5304.000000</td>
      <td>5654.000000</td>
      <td>5642.000000</td>
      <td>6450.000000</td>
      <td>5194.000000</td>
      <td>9.000000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 21 columns</p>
</div>




```python
data_merged=data_merged.loc[data_merged['country_id_y']!=9,]
```

### No LifeTime Trips


```python
#data.loc[:,'dormant']=False
data_merged.loc[data_merged.life_time_gmv_earned_usd.isnull(),'life_time_trips']=0
#data['dormant'].value_counts()
```


```python
data_merged.loc[:,'dormant']=False
data_merged.loc[data_merged.life_time_trips==0,'dormant']=True

data_merged['dormant'].value_counts(normalize=True)*100
```




    False    88.311056
    True     11.688944
    Name: dormant, dtype: float64




```python
data_merged.loc[data_merged.dormant==True,'zeus_days_to_first_order']=10000
```

#### Insights : 10% Overall with No Trips

### Overall Stats 


```python
data_merged['business_model'].value_counts(normalize=True)*100
```




    Concierge     55.143798
    Integrated    44.856202
    Name: business_model, dtype: float64




```python
data_merged['is_partner'].value_counts(normalize=True)*100
```




    True     53.206125
    False    46.793875
    Name: is_partner, dtype: float64




```python
data_merged['is_bd_account'].value_counts(normalize=True)*100
```




    False    94.428723
    True      5.571277
    Name: is_bd_account, dtype: float64




```python
data_merged['is_bd_partner'].value_counts(normalize=True)*100
```




    False    95.029803
    True      4.970197
    Name: is_bd_partner, dtype: float64



### Country-wise Stats


```python
data_merged.groupby(['country_name'])['business_model'].value_counts(normalize=True)*100
```




    country_name  business_model
    Indonesia     Concierge          58.582137
                  Integrated         41.417863
    Malaysia      Integrated         99.853480
                  Concierge           0.146520
    Philippines   Concierge          98.565299
                  Integrated          1.434701
    Singapore     Integrated        100.000000
    Thailand      Integrated         70.755989
                  Concierge          29.244011
    Vietnam       Integrated         64.611557
                  Concierge          35.388443
    Name: business_model, dtype: float64




```python
data_merged.groupby(['country_name'])['is_partner'].value_counts(normalize=True)*100
```




    country_name  is_partner
    Indonesia     False          54.148007
                  True           45.851993
    Malaysia      True           99.902320
                  False           0.097680
    Philippines   True           94.717082
                  False           5.282918
    Singapore     True          100.000000
    Thailand      True           89.422379
                  False          10.577621
    Vietnam       True           70.371394
                  False          29.628606
    Name: is_partner, dtype: float64




```python
data_merged.groupby(['country_name'])['is_bd_account'].value_counts(normalize=True)*100
```




    country_name  is_bd_account
    Indonesia     False            97.471943
                  True              2.528057
    Malaysia      False            76.336996
                  True             23.663004
    Philippines   False            64.521319
                  True             35.478681
    Singapore     False            90.581330
                  True              9.418670
    Thailand      False            79.072903
                  True             20.927097
    Vietnam       False            90.821122
                  True              9.178878
    Name: is_bd_account, dtype: float64




```python
data_merged.groupby(['country_name'])['is_bd_partner'].value_counts(normalize=True)*100
```




    country_name  is_bd_partner
    Indonesia     False            98.120758
                  True              1.879242
    Malaysia      False            76.336996
                  True             23.663004
    Philippines   False            64.521319
                  True             35.478681
    Singapore     False            90.581330
                  True              9.418670
    Thailand      False            79.332158
                  True             20.667842
    Vietnam       False            91.844070
                  True              8.155930
    Name: is_bd_partner, dtype: float64



### Stats for Surabaya


```python
data_surabaya=data_merged[data_merged.city_id==18]
```


```python
len(data_surabaya)
```




    21506




```python
data_surabaya['is_bd_account'].value_counts(normalize=True)*100
```




    False   98
    True     2
    Name: is_bd_account, dtype: float64




```python
data_surabaya['business_model'].value_counts(normalize=True)*100
```




    Concierge    53
    Integrated   47
    Name: business_model, dtype: float64




```python
data_surabaya['is_bd_partner'].value_counts(normalize=True)*100
```




    False    98.205152
    True      1.794848
    Name: is_bd_partner, dtype: float64




```python
data_surabaya['is_partner'].value_counts(normalize=True)*100
```




    True     50.446387
    False    49.553613
    Name: is_partner, dtype: float64




```python
data_dormant=data_merged.loc[data_merged.dormant==True,]
non_dormant_data=data_merged.loc[data_merged.dormant==False,]
# Surabat
data_dormant_Surabaya=data_surabaya.loc[data_surabaya.dormant==True,]
non_dormant_data_Surabaya=data_surabaya.loc[data_surabaya.dormant==False,]

```


```python
data_surabaya.groupby(['business_model'])['life_time_gmv_earned_usd'].agg(['sum'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sum</th>
    </tr>
    <tr>
      <th>business_model</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Concierge</th>
      <td>10730302</td>
    </tr>
    <tr>
      <th>Integrated</th>
      <td>21268727</td>
    </tr>
  </tbody>
</table>
</div>




```python

data_surabaya.groupby(['is_partner'])['life_time_gmv_earned_usd'].agg(['sum'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sum</th>
    </tr>
    <tr>
      <th>is_partner</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>False</th>
      <td>5263229</td>
    </tr>
    <tr>
      <th>True</th>
      <td>26735799</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
data_surabaya.groupby(['is_bd_account'])['life_time_gmv_earned_usd'].agg(['sum'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sum</th>
    </tr>
    <tr>
      <th>is_bd_account</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>False</th>
      <td>21781603</td>
    </tr>
    <tr>
      <th>True</th>
      <td>10217426</td>
    </tr>
  </tbody>
</table>
</div>




```python
data_surabaya['dormant'].value_counts(normalize=True)*100
```




    False   82
    True    18
    Name: dormant, dtype: float64




```python
data_surabaya['business_name'].nunique()
```




    19248



### Days to FT


```python
overall_country=non_dormant_data.groupby(['country_name'])['zeus_days_to_first_order'].quantile(np.linspace(0,1,101)).unstack()
```


```python
#import matplotlib.ticker as mtick
from matplotlib.pyplot import figure
import matplotlib.pyplot as plt
plt.figure(figsize=(100,100))
ax=overall_country.T.plot()
ax.axvline(x=0.8, color='r', linestyle='--')
ax.axhline(y=20, color='g', linestyle='--')
plt.ylabel("Days : Activation to FT")
plt.xlabel("Fraction of GF MEX")
#plt.title('Days taken from Active to FT')
ax.text(0.5, 0.45, '20 days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
#ax.text(0.5, 0.35, '18 days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
ax.text(0.75, 0.9, '80% GF MEX', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
plt.ylim(0,200)

```




    (0, 200)




    <Figure size 7200x7200 with 0 Axes>



![png](output_41_2.png)



```python
non_dormant_data.groupby(['country_name'])['zeus_days_to_first_order'].quantile([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]).unstack()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0.1</th>
      <th>0.2</th>
      <th>0.3</th>
      <th>0.4</th>
      <th>0.5</th>
      <th>0.6</th>
      <th>0.7</th>
      <th>0.8</th>
      <th>0.9</th>
      <th>1.0</th>
    </tr>
    <tr>
      <th>country_name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Indonesia</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>3.0</td>
      <td>5.0</td>
      <td>9.0</td>
      <td>17.0</td>
      <td>33.0</td>
      <td>310.0</td>
    </tr>
    <tr>
      <th>Malaysia</th>
      <td>7.0</td>
      <td>12.0</td>
      <td>16.0</td>
      <td>20.0</td>
      <td>26.0</td>
      <td>32.0</td>
      <td>41.0</td>
      <td>54.0</td>
      <td>78.0</td>
      <td>230.0</td>
    </tr>
    <tr>
      <th>Philippines</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>4.0</td>
      <td>7.0</td>
      <td>12.0</td>
      <td>26.0</td>
      <td>281.0</td>
    </tr>
    <tr>
      <th>Singapore</th>
      <td>6.0</td>
      <td>7.0</td>
      <td>10.0</td>
      <td>13.0</td>
      <td>16.0</td>
      <td>20.0</td>
      <td>25.0</td>
      <td>31.0</td>
      <td>45.0</td>
      <td>227.0</td>
    </tr>
    <tr>
      <th>Thailand</th>
      <td>1.0</td>
      <td>5.0</td>
      <td>7.0</td>
      <td>10.0</td>
      <td>13.0</td>
      <td>15.0</td>
      <td>19.0</td>
      <td>25.0</td>
      <td>39.0</td>
      <td>268.0</td>
    </tr>
    <tr>
      <th>Vietnam</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>3.0</td>
      <td>7.0</td>
      <td>19.0</td>
      <td>293.0</td>
    </tr>
  </tbody>
</table>
</div>



### Analysis for Surabaya


```python
non_dormant_data_Surabaya.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country_id_x</th>
      <th>city_id</th>
      <th>latest_commission_rate</th>
      <th>zeus_days_to_first_order</th>
      <th>days_to_first_order</th>
      <th>days_to_activation</th>
      <th>life_time_trips</th>
      <th>life_time_gmv_earned_usd</th>
      <th>life_time_gmv_earned_local</th>
      <th>life_time_uniq_pax</th>
      <th>...</th>
      <th>food_trips_second_week</th>
      <th>food_trips_third_week</th>
      <th>food_trips_fourth_week</th>
      <th>food_trips_fifth_week</th>
      <th>food_trips_sixth_week</th>
      <th>food_trips_seventh_week</th>
      <th>food_trips_eighth_week</th>
      <th>food_trips_ninth_week</th>
      <th>food_trips_tenth_week</th>
      <th>country_id_y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>17560.0</td>
      <td>17560.0</td>
      <td>17560.000000</td>
      <td>17560.000000</td>
      <td>17560.000000</td>
      <td>17560.000000</td>
      <td>17560.000000</td>
      <td>17560.000000</td>
      <td>1.756000e+04</td>
      <td>17560.00000</td>
      <td>...</td>
      <td>17560.000000</td>
      <td>17560.000000</td>
      <td>17560.000000</td>
      <td>17560.000000</td>
      <td>17560.000000</td>
      <td>17560.000000</td>
      <td>17560.000000</td>
      <td>17560.00000</td>
      <td>17560.000000</td>
      <td>17560.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>6.0</td>
      <td>18.0</td>
      <td>0.104311</td>
      <td>11.532118</td>
      <td>12.450342</td>
      <td>-0.025000</td>
      <td>471.712585</td>
      <td>1822.268145</td>
      <td>2.584371e+07</td>
      <td>298.88713</td>
      <td>...</td>
      <td>17.422437</td>
      <td>38.283599</td>
      <td>19.408770</td>
      <td>19.146469</td>
      <td>17.871811</td>
      <td>17.699829</td>
      <td>17.098747</td>
      <td>16.55951</td>
      <td>16.342312</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.095274</td>
      <td>21.845749</td>
      <td>21.979507</td>
      <td>2.855002</td>
      <td>2371.746807</td>
      <td>10483.608585</td>
      <td>1.487664e+08</td>
      <td>1216.86312</td>
      <td>...</td>
      <td>85.402457</td>
      <td>159.991179</td>
      <td>82.024846</td>
      <td>83.002765</td>
      <td>74.263910</td>
      <td>80.337053</td>
      <td>77.779880</td>
      <td>79.82217</td>
      <td>77.371816</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>min</th>
      <td>6.0</td>
      <td>18.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-112.000000</td>
      <td>1.000000</td>
      <td>0.421010</td>
      <td>6.000000e+03</td>
      <td>1.00000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>6.0</td>
      <td>18.0</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>8.000000</td>
      <td>22.946102</td>
      <td>3.244688e+05</td>
      <td>7.00000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>6.0</td>
      <td>18.0</td>
      <td>0.181800</td>
      <td>3.000000</td>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>47.000000</td>
      <td>147.230047</td>
      <td>2.088850e+06</td>
      <td>39.00000</td>
      <td>...</td>
      <td>3.000000</td>
      <td>6.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>6.0</td>
      <td>18.0</td>
      <td>0.181800</td>
      <td>12.000000</td>
      <td>13.000000</td>
      <td>0.000000</td>
      <td>250.000000</td>
      <td>779.650040</td>
      <td>1.104325e+07</td>
      <td>190.00000</td>
      <td>...</td>
      <td>13.000000</td>
      <td>27.000000</td>
      <td>13.000000</td>
      <td>12.000000</td>
      <td>11.000000</td>
      <td>10.000000</td>
      <td>9.000000</td>
      <td>8.00000</td>
      <td>7.000000</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>6.0</td>
      <td>18.0</td>
      <td>0.273000</td>
      <td>261.000000</td>
      <td>262.000000</td>
      <td>81.000000</td>
      <td>110135.000000</td>
      <td>399194.832348</td>
      <td>5.665129e+09</td>
      <td>38237.00000</td>
      <td>...</td>
      <td>5050.000000</td>
      <td>7197.000000</td>
      <td>3361.000000</td>
      <td>3748.000000</td>
      <td>3065.000000</td>
      <td>3457.000000</td>
      <td>3145.000000</td>
      <td>3209.00000</td>
      <td>3122.000000</td>
      <td>6.0</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 21 columns</p>
</div>




```python
overall_country_surabaya=non_dormant_data_Surabaya.groupby(['city_name'])['zeus_days_to_first_order'].quantile(np.linspace(0,1,101)).unstack()
#import matplotlib.ticker as mtick
plt.figure(figsize=(100,100))
ax=overall_country_surabaya.T.plot()
ax.axvline(x=0.7, color='r', linestyle='--')
ax.axhline(y=9, color='g', linestyle='--')
plt.ylabel("Days : Activation to FT")
plt.xlabel("Fraction of GF MEX")
#plt.title('Days taken from Active to FT')
ax.text(0.5, 0.45, '9 days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
#ax.text(0.5, 0.35, '18 days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
ax.text(0.75, 0.9, '70% GF MEX', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)


```




    Text(0.75, 0.9, '70% GF MEX')




    <Figure size 7200x7200 with 0 Axes>



![png](output_45_2.png)



```python
non_dormant_data_Surabaya.groupby(['city_name'])['zeus_days_to_first_order'].quantile([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]).unstack()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0.1</th>
      <th>0.2</th>
      <th>0.3</th>
      <th>0.4</th>
      <th>0.5</th>
      <th>0.6</th>
      <th>0.7</th>
      <th>0.8</th>
      <th>0.9</th>
      <th>1.0</th>
    </tr>
    <tr>
      <th>city_name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Surabaya</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>3.0</td>
      <td>6.0</td>
      <td>9.0</td>
      <td>17.0</td>
      <td>30.0</td>
      <td>261.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
overall_country_surabaya=non_dormant_data_Surabaya.groupby(['is_bd_account'])['zeus_days_to_first_order'].quantile(np.linspace(0,1,101)).unstack()
#import matplotlib.ticker as mtick
plt.figure(figsize=(100,100))
ax=overall_country_surabaya.T.plot()
ax.axvline(x=0.8, color='r', linestyle='--')
ax.axhline(y=10, color='g', linestyle='--')
plt.ylabel("Days : Activation to FT")
plt.xlabel("Fraction of GF MEX")
#plt.title('Days taken from Active to FT')
ax.text(0.5, 0.45, 'Non BD: 17 days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
ax.text(0.5, 0.35, 'BD: 2 days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
ax.text(0.75, 0.9, '80% GF MEX', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)


```




    Text(0.75, 0.9, '80% GF MEX')




    <Figure size 7200x7200 with 0 Axes>



![png](output_47_2.png)



```python
non_dormant_data_Surabaya.groupby(['is_bd_account'])['zeus_days_to_first_order'].quantile([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]).unstack()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0.1</th>
      <th>0.2</th>
      <th>0.3</th>
      <th>0.4</th>
      <th>0.5</th>
      <th>0.6</th>
      <th>0.7</th>
      <th>0.8</th>
      <th>0.9</th>
      <th>1.0</th>
    </tr>
    <tr>
      <th>is_bd_account</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>False</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>4.0</td>
      <td>6.0</td>
      <td>9.0</td>
      <td>17.0</td>
      <td>31.0</td>
      <td>261.0</td>
    </tr>
    <tr>
      <th>True</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>6.7</td>
      <td>103.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
overall_country_surabaya=non_dormant_data_Surabaya.groupby(['business_model'])['zeus_days_to_first_order'].quantile(np.linspace(0,1,101)).unstack()
#import matplotlib.ticker as mtick
plt.figure(figsize=(100,100))
ax=overall_country_surabaya.T.plot()
ax.axvline(x=0.8, color='r', linestyle='--')
ax.axhline(y=23, color='b', linestyle='--')
ax.axhline(y=12, color='g', linestyle='--')
plt.ylabel("Days : Activation to FT")
plt.xlabel("Fraction of GF MEX")
#plt.title('Days taken from Active to FT')
ax.text(0.5, 0.45, 'Concierge: 12 days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
ax.text(0.5, 0.35, 'Integrated: 23 days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
ax.text(0.75, 0.9, '80% GF MEX', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)


```




    Text(0.75, 0.9, '80% GF MEX')




    <Figure size 7200x7200 with 0 Axes>



![png](output_49_2.png)



```python
non_dormant_data_Surabaya.groupby(['business_model'])['days_to_first_order'].quantile([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]).unstack()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0.1</th>
      <th>0.2</th>
      <th>0.3</th>
      <th>0.4</th>
      <th>0.5</th>
      <th>0.6</th>
      <th>0.7</th>
      <th>0.8</th>
      <th>0.9</th>
      <th>1.0</th>
    </tr>
    <tr>
      <th>business_model</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Concierge</th>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>3.0</td>
      <td>5.0</td>
      <td>7.0</td>
      <td>12.0</td>
      <td>25.0</td>
      <td>200.0</td>
    </tr>
    <tr>
      <th>Integrated</th>
      <td>1.0</td>
      <td>2.0</td>
      <td>3.0</td>
      <td>4.0</td>
      <td>6.0</td>
      <td>8.0</td>
      <td>14.0</td>
      <td>23.0</td>
      <td>37.0</td>
      <td>262.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
overall_country_surabaya=non_dormant_data_Surabaya.groupby(['is_partner'])['zeus_days_to_first_order'].quantile(np.linspace(0,1,101)).unstack()
#import matplotlib.ticker as mtick
plt.figure(figsize=(100,100))
ax=overall_country_surabaya.T.plot()
ax.axvline(x=0.7, color='r', linestyle='--')
ax.axhline(y=10, color='g', linestyle='--')
plt.ylabel("Days : Activation to FT")
plt.xlabel("Fraction of GF MEX")
#plt.title('Days taken from Active to FT')
ax.text(0.5, 0.45, 'x days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
#ax.text(0.5, 0.35, '18 days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
ax.text(0.75, 0.9, '70% GF MEX', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)


```




    Text(0.75, 0.9, '70% GF MEX')




    <Figure size 7200x7200 with 0 Axes>



![png](output_51_2.png)



```python
non_dormant_data_Surabaya.groupby(['is_partner'])['zeus_days_to_first_order'].quantile([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]).unstack()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0.1</th>
      <th>0.2</th>
      <th>0.3</th>
      <th>0.4</th>
      <th>0.5</th>
      <th>0.6</th>
      <th>0.7</th>
      <th>0.8</th>
      <th>0.9</th>
      <th>1.0</th>
    </tr>
    <tr>
      <th>is_partner</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>False</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>4.0</td>
      <td>7.0</td>
      <td>11.8</td>
      <td>24.0</td>
      <td>199.0</td>
    </tr>
    <tr>
      <th>True</th>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>3.0</td>
      <td>4.0</td>
      <td>7.0</td>
      <td>12.0</td>
      <td>21.0</td>
      <td>35.0</td>
      <td>261.0</td>
    </tr>
  </tbody>
</table>
</div>




```python

nd_surabaya_monthwise=non_dormant_data_Surabaya.groupby(pd.to_datetime(non_dormant_data_Surabaya['zeus_created_at']).dt.month_name())['zeus_days_to_first_order'].quantile(np.linspace(0,1,101)).unstack()

```


```python
#overall_country_surabaya=non_dormant_surabaya.groupby(['is_partner'])['zeus_days_to_first_order'].quantile(np.linspace(0,1,101)).unstack()
#import matplotlib.ticker as mtick
plt.figure(figsize=(100,100))
ax=nd_surabaya_monthwise.T.plot()
ax.axvline(x=0.7, color='r', linestyle='--')
ax.axhline(y=10, color='g', linestyle='--')
plt.ylabel("Days : Activation to FT")
plt.xlabel("Fraction of GF MEX")
#plt.title('Days taken from Active to FT')
ax.text(0.5, 0.45, 'x days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
#ax.text(0.5, 0.35, '18 days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
ax.text(0.75, 0.9, '70% GF MEX', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
plt.ylim(0,50)

```




    (0, 50)




    <Figure size 7200x7200 with 0 Axes>



![png](output_54_2.png)



```python
non_dormant_data_Surabaya.groupby(pd.to_datetime(non_dormant_data_Surabaya['zeus_created_at']).dt.month_name())['zeus_days_to_first_order'].quantile([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]).unstack()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0.1</th>
      <th>0.2</th>
      <th>0.3</th>
      <th>0.4</th>
      <th>0.5</th>
      <th>0.6</th>
      <th>0.7</th>
      <th>0.8</th>
      <th>0.9</th>
      <th>1.0</th>
    </tr>
    <tr>
      <th>zeus_created_at</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>April</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>5</td>
      <td>7</td>
      <td>13</td>
      <td>25</td>
      <td>61</td>
      <td>205</td>
    </tr>
    <tr>
      <th>August</th>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>4</td>
      <td>6</td>
      <td>9</td>
      <td>14</td>
      <td>26</td>
      <td>105</td>
    </tr>
    <tr>
      <th>February</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>5</td>
      <td>8</td>
      <td>18</td>
      <td>59</td>
      <td>261</td>
    </tr>
    <tr>
      <th>January</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>4</td>
      <td>8</td>
      <td>23</td>
      <td>186</td>
    </tr>
    <tr>
      <th>July</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>4</td>
      <td>8</td>
      <td>21</td>
      <td>129</td>
    </tr>
    <tr>
      <th>June</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>4</td>
      <td>7</td>
      <td>12</td>
      <td>23</td>
      <td>47</td>
      <td>156</td>
    </tr>
    <tr>
      <th>March</th>
      <td>0</td>
      <td>1</td>
      <td>4</td>
      <td>6</td>
      <td>8</td>
      <td>11</td>
      <td>17</td>
      <td>24</td>
      <td>68</td>
      <td>244</td>
    </tr>
    <tr>
      <th>May</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>6</td>
      <td>12</td>
      <td>22</td>
      <td>30</td>
      <td>50</td>
      <td>183</td>
    </tr>
    <tr>
      <th>November</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>4</td>
      <td>6</td>
      <td>8</td>
      <td>15</td>
    </tr>
    <tr>
      <th>October</th>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>8</td>
      <td>11</td>
      <td>17</td>
      <td>43</td>
    </tr>
    <tr>
      <th>September</th>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>7</td>
      <td>14</td>
      <td>23</td>
      <td>30</td>
      <td>73</td>
    </tr>
  </tbody>
</table>
</div>




```python
non_dormant_data_Surabaya.groupby(pd.to_datetime(non_dormant_data_Surabaya['zeus_created_at']).dt.month_name())[['food_trips_first_week','food_trips_second_week','food_trips_third_week','food_trips_fourth_week','food_trips_fifth_week','food_trips_sixth_week','food_trips_seventh_week','food_trips_eighth_week','food_trips_ninth_week','food_trips_tenth_week']].agg('sum')

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>food_trips_first_week</th>
      <th>food_trips_second_week</th>
      <th>food_trips_third_week</th>
      <th>food_trips_fourth_week</th>
      <th>food_trips_fifth_week</th>
      <th>food_trips_sixth_week</th>
      <th>food_trips_seventh_week</th>
      <th>food_trips_eighth_week</th>
      <th>food_trips_ninth_week</th>
      <th>food_trips_tenth_week</th>
    </tr>
    <tr>
      <th>zeus_created_at</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>April</th>
      <td>18377</td>
      <td>22670</td>
      <td>54311</td>
      <td>26717</td>
      <td>26593</td>
      <td>27151</td>
      <td>30633</td>
      <td>32584</td>
      <td>34547</td>
      <td>38502</td>
    </tr>
    <tr>
      <th>August</th>
      <td>31089</td>
      <td>44368</td>
      <td>113304</td>
      <td>61172</td>
      <td>64289</td>
      <td>61847</td>
      <td>57179</td>
      <td>56123</td>
      <td>54890</td>
      <td>50780</td>
    </tr>
    <tr>
      <th>February</th>
      <td>11551</td>
      <td>17407</td>
      <td>36315</td>
      <td>18108</td>
      <td>18620</td>
      <td>20614</td>
      <td>21282</td>
      <td>21543</td>
      <td>24078</td>
      <td>26558</td>
    </tr>
    <tr>
      <th>January</th>
      <td>12980</td>
      <td>15065</td>
      <td>33573</td>
      <td>16425</td>
      <td>18268</td>
      <td>18612</td>
      <td>19052</td>
      <td>19975</td>
      <td>20062</td>
      <td>21720</td>
    </tr>
    <tr>
      <th>July</th>
      <td>22717</td>
      <td>27986</td>
      <td>61064</td>
      <td>32221</td>
      <td>32887</td>
      <td>32203</td>
      <td>33003</td>
      <td>32029</td>
      <td>31540</td>
      <td>31985</td>
    </tr>
    <tr>
      <th>June</th>
      <td>32510</td>
      <td>34326</td>
      <td>74176</td>
      <td>39138</td>
      <td>37384</td>
      <td>38499</td>
      <td>38929</td>
      <td>37484</td>
      <td>35191</td>
      <td>34215</td>
    </tr>
    <tr>
      <th>March</th>
      <td>15475</td>
      <td>19130</td>
      <td>42601</td>
      <td>24337</td>
      <td>26597</td>
      <td>25221</td>
      <td>33205</td>
      <td>30264</td>
      <td>31290</td>
      <td>31565</td>
    </tr>
    <tr>
      <th>May</th>
      <td>22201</td>
      <td>28574</td>
      <td>72907</td>
      <td>46010</td>
      <td>48920</td>
      <td>43802</td>
      <td>46904</td>
      <td>49631</td>
      <td>49220</td>
      <td>49740</td>
    </tr>
    <tr>
      <th>November</th>
      <td>6234</td>
      <td>2957</td>
      <td>26</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>October</th>
      <td>30174</td>
      <td>38165</td>
      <td>67460</td>
      <td>20982</td>
      <td>11723</td>
      <td>2423</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>September</th>
      <td>45227</td>
      <td>55290</td>
      <td>116523</td>
      <td>55708</td>
      <td>50931</td>
      <td>43457</td>
      <td>30622</td>
      <td>20621</td>
      <td>9967</td>
      <td>1906</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.options.display.float_format = '{:.0f}'.format


non_dormant_data_Surabaya.groupby(pd.to_datetime(non_dormant_data_Surabaya['zeus_created_at']).dt.month)['merchant_id','life_time_gmv_earned_usd'].agg(['count','sum'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="2" halign="left">merchant_id</th>
      <th colspan="2" halign="left">life_time_gmv_earned_usd</th>
    </tr>
    <tr>
      <th></th>
      <th>count</th>
      <th>sum</th>
      <th>count</th>
      <th>sum</th>
    </tr>
    <tr>
      <th>zeus_created_at</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>829</td>
      <td>AWh0hCfNZXYdMpch2U1bAWiYjyGOfYWaYaQC4q-pAWgtvp...</td>
      <td>829</td>
      <td>4619152</td>
    </tr>
    <tr>
      <th>2</th>
      <td>803</td>
      <td>AWjQI49Akk5cOZVWvSaVAWkE8hl6kk5cOZVWvcr1AWkpkN...</td>
      <td>803</td>
      <td>4329328</td>
    </tr>
    <tr>
      <th>3</th>
      <td>548</td>
      <td>6-CYLAAADCLRBJLJ6-CYK1JCEAPBDHRX6-CYKURNXAPAME...</td>
      <td>548</td>
      <td>4877348</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1221</td>
      <td>6-CYLZNF6ZNRE3AJ6-CYMGGFLFGGJTVA6-CYL2LP3CVN6C...</td>
      <td>1221</td>
      <td>3528372</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1750</td>
      <td>6-CYNUC32EGP6XLT6-CYM3VLKWWFWJNJ6-CYMJUFVFG63Z...</td>
      <td>1750</td>
      <td>4941035</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2041</td>
      <td>6-CYN2DBUZVCEVGN6-CYTCJXDDVJ32L26-CYTATK42BGKU...</td>
      <td>2041</td>
      <td>2947209</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1651</td>
      <td>6-CYUXGCNZTFK2GN6-CYU2TYTBLET3AJ6-CYUFR8DFVUCC...</td>
      <td>1651</td>
      <td>2076298</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2224</td>
      <td>6-CYWUGLKEHALEL66-CYWBAKEJAKTAVA6-CYWBAKJXLAVJ...</td>
      <td>2224</td>
      <td>2268380</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2862</td>
      <td>6-CYWZTYJWBAKBG26-CYXZN6KYNTXHET6-CYXDKFLYRZDH...</td>
      <td>2862</td>
      <td>1787171</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2710</td>
      <td>6-CY23WGNCNE2FC26-CY3CJPJCAJEEJ66-CY2GCATFCGLT...</td>
      <td>2710</td>
      <td>584323</td>
    </tr>
    <tr>
      <th>11</th>
      <td>921</td>
      <td>6-CY3ZGBLAC3W2L26-CY31T65BJP21EE6-CY3YG7CDVEWD...</td>
      <td>921</td>
      <td>40412</td>
    </tr>
  </tbody>
</table>
</div>




```python
#bins=[0,5,10,15,20,25,30,35,40,50,60,70,80,90,100,200,300,400,500,600,700,800,900,1000]
bins= [i for i in np.arange(0,1000,50)]

#bins=np.linspace(0,1000,10)
#bins=bins.tolist()
#group = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13','14','15','16','17','18','19','20','21','22','23']
s=pd.cut(non_dormant_data_Surabaya['life_time_trips'], bins=bins).value_counts()
#
#kk=pd.cut(non_dormant_surabaya.groupby(pd.to_datetime(non_dormant_surabaya['zeus_created_at']).dt.month)['life_time_trips'], bins=bins,labels=group).value_counts()
```


```python
s
```




    (0, 50]       8970
    (50, 100]     1858
    (100, 150]    1040
    (150, 200]     750
    (200, 250]     554
    (250, 300]     452
    (300, 350]     344
    (350, 400]     314
    (400, 450]     281
    (450, 500]     232
    (500, 550]     206
    (550, 600]     158
    (650, 700]     146
    (600, 650]     138
    (750, 800]     114
    (700, 750]     107
    (850, 900]      97
    (800, 850]      89
    (900, 950]      75
    Name: life_time_trips, dtype: int64




```python
k=s.tolist()
```


```python
plt.figure(figsize=(10,10))
s.T.plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x123ff77b8>




![png](output_61_1.png)



```python
plt.hist(s, bins=bins, density=True, histtype='step', cumulative=-1,
        label='Reversed emp.')
plt.axvline(x=100, color='r', linestyle='--')

plt.ylabel("Percentage of MEX")
plt.xlabel("Lifetime Food Orders")
```




    Text(0.5, 0, 'Lifetime Food Orders')




![png](output_62_1.png)


### 80% of the MEX make less than 100 Orders


```python
non_dormant_data_Surabaya['food_trips_first_week'].value_counts()
```




    0       3981
    1       2232
    2       1465
    3       1193
    4        940
    5        782
    6        642
    7        523
    8        473
    9        404
    10       362
    11       321
    12       262
    13       237
    15       220
    14       214
    17       180
    18       177
    16       174
    19       160
    21       133
    20       131
    23       108
    22       107
    24        98
    28        87
    26        82
    25        80
    29        77
    32        74
            ... 
    421        1
    277        1
    229        1
    149        1
    1268       1
    468        1
    388        1
    372        1
    726        1
    950        1
    154        1
    1686       1
    1417       1
    1065       1
    825        1
    697        1
    537        1
    441        1
    297        1
    217        1
    440        1
    328        1
    264        1
    152        1
    120        1
    1047       1
    631        1
    295        1
    1103       1
    279        1
    Name: food_trips_first_week, Length: 282, dtype: int64




```python
overall_firstweek_surabaya=non_dormant_data_Surabaya.groupby(['is_partner'])['food_trips_first_week'].quantile(np.linspace(0,1,101)).unstack()
#import matplotlib.ticker as mtick
plt.figure(figsize=(100,100))
ax=overall_firstweek_surabaya.T.plot()
ax.axvline(x=0.7, color='r', linestyle='--')
ax.axhline(y=10, color='g', linestyle='--')
plt.ylabel("Days : Activation to FT")
plt.xlabel("Fraction of GF MEX")
#plt.title('Days taken from Active to FT')
ax.text(0.5, 0.45, 'x days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
#ax.text(0.5, 0.35, '18 days', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)
ax.text(0.75, 0.9, '70% GF MEX', horizontalalignment='center',verticalalignment='center', transform=ax.transAxes)


```




    Text(0.75, 0.9, '70% GF MEX')




    <Figure size 7200x7200 with 0 Axes>



![png](output_65_2.png)



```python

```
